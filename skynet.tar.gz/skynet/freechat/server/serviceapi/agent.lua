local skynet = require "skynet"
local Agent = {}

function Agent.Start(agent, gate, fd)
    skynet.send(agent, "lua", "Start", gate, fd)
end

function Agent.Stop(agent)
    skynet.send(agent, "lua", "Stop")
end

function Agent.Data(agent, msg)
    skynet.send(agent, "lua", "Data", msg)
end

return Agent

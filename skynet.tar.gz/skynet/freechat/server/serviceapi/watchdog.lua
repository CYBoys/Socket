local skynet = require "skynet"

local Watchdog = {}

function Watchdog.Start(watchdog, port, maxclient, nodelay)
    skynet.call(watchdog, "lua", "Start", port, maxclient, nodelay)
end

function Watchdog.AgentClose(watchdog, agent)
    skynet.send(watchdog, "lua", "AgentClose", agent)
end

return Watchdog

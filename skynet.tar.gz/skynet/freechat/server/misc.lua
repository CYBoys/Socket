local skynet = require "skynet"
local Misc = {}
local upper, lower = string.upper, string.lower

function Misc.GetStrEnv(key)
    return skynet.getenv(key)
end

function Misc.GetNumEnv(key)
    local env = skynet.getenv(key)
    return tonumber(env)
end

function Misc.GetBoolEnv(key)
    local env = lower(skynet.getenv(key))
    assert(env == "true" or env == "false")
    if env == "true" then
        return true
    end
    return false
end

return Misc

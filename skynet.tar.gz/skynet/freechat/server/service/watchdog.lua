local skynet = require "skynet"
local Misc = require "misc"
local Queue = require "stdlib.queue"
local Agent = require "serviceapi.agent"

local SOCKET = {}
local CMD = {}

local gate
local AgentQueue = Queue.New()
local AgentHash = {}

function SOCKET.open(fd, addr)
    local agent = AgentQueue:Pop()
    if agent then
        AgentHash[fd] = agent
        Agent.Start(agent, gate, fd)
    end
end

function SOCKET.close(fd)
    local agent = AgentHash[fd]
    Agent.Stop(agent)
    AgentHash[fd] = nil
    AgentQueue:Push(agent)
end

function SOCKET.error(fd)
    SOCKET.close(fd)
end

function SOCKET.data(fd, msg)
    local agent = AgentHash[fd]
    Agent.Data(agent, msg)
end

function CMD.Start(port, maxclient, nodelay)
    local maxclient = Misc.GetNumEnv("maxclient")
    for i=1, maxclient do
        local agent = skynet.newservice("agent")
        AgentQueue:Push(agent)
    end
    skynet.call(gate, "lua", "open", {
                    port = port,
                    maxclient = maxclient,
                    nodelay = nodelay,
    })
end

function CMD.AgentClose(agent, fd)
    AgentHash[fd] = nil
    AgentQueue:Push(agent)
    skynet.call(gate, "lua", "close", fd)
end

skynet.start(function()
        skynet.dispatch("lua", function(session, source, cmd, subcmd, ...)
                            if cmd == "socket" then
                                local f = assert(SOCKET[subcmd])
                                f(...)
                            else
                                local f = assert(CMD[cmd])
                                skynet.ret(skynet.pack(f(subcmd, ...)))
                            end
        end)
        gate = skynet.newservice("gate")
end)


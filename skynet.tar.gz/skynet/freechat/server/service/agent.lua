local skynet = require "skynet"
local socket = require "socket"
local Watchdog = require "serviceapi.watchdog"
local runtime = {}
local CMD = {}

local function SendPackage(pack)
    local package = string.pack(">s2", pack)
	socket.write(runtime.fd, package)
end

local function AgentClose()
    Watchdog.ActiveClose(skynet.self(), fd)
    runtime = {}
end

function CMD.Start(gate, fd)
    runtime.gate = gate
    runtime.fd = fd
    skynet.call(gate, "lua", "accept", fd)
end

function CMD.Stop()
    runtime = {}
end

function CMD.Data(msg)
    skynet.error(msg)
    SendPackage(msg)
end

skynet.start(function()
        skynet.dispatch("lua", function(session, source, cmd, ...)
                            local f = assert(CMD[cmd])
                            local ret = f(...)
                            if ret then
                                skynet.ret(skynet.pack(ret))
                            end
        end)
end)

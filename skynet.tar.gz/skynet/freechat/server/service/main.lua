local skynet = require "skynet"
local Watchdog = require "serviceapi.watchdog"
local Misc = require "misc"

skynet.start(function()
        skynet.error("Server start...")
        local watchdog = skynet.newservice("watchdog")
        local port = Misc.GetNumEnv("port")
        local maxclient = Misc.GetNumEnv("maxclient")
        local nodelay = Misc.GetBoolEnv("nodelay")
        Watchdog.Start(watchdog, port, maxclient, nodelay)
        skynet.error(string.format("Watchdog listen on %d", port))
        
        skynet.exit()
end)

local Set = {}

function Set.Pairs(obj)
    return pairs(obj.data)
end

function Set.New()
    local obj = {
        data = {},
        size = 0,
    }
    local mt = {
        __index = Set,
        __pairs = Set.Pairs,
    }
    return setmetatable(obj, mt)
end

function Set:Empty()
    if self:Size() == 0 then
        return true
    end
    return false
end

function Set:Size()
    return self.size
end

function Set:Insert(elem)
    self.data[elem] = true
    self.size = self.size + 1
end

function Set:Find(elem)
    return self.data[elem] and elem
end

function Set:Erase(elem)
    self.data[elem] = nil
    self.size = self.size - 1
end

function Set:Clear()
    self.data = {}
    self.size = 0
end

return Set

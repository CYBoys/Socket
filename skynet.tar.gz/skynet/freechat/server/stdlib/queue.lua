local Queue = {}

function Queue.Pairs(obj)
    return pairs(obj.data)
end

function Queue.New(vol)
    local obj = {
        volume = vol,
        data = {},
        size = 0,
    }
    return setmetatable(obj, {__index = Queue, __pairs = Queue.Pairs})
end

function Queue:Volume()
    return self.volume
end

function Queue:Size()
    return self.size
end

function Queue:Empty()
    if self:Size() == 0 then
        return true
    end
    return false
end

function Queue:Push(elem)
    if self:Volume() ~= nil and self:Size() >= self:Volume() then
        self:Pop()
    end
    table.insert(self.data, elem)
    self.size = self.size + 1
end

function Queue:Pop()
    local elem = table.remove(self.data, 1)
    if elem then
        self.size = self.size - 1
    end
    return elem
end

function Queue:Clear()
    self.data = {}
    self.size = 0
end

return Queue

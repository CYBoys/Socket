#! /usr/bin/python

import socket
import struct

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  
sock.connect(('127.0.0.1', 8888))
msg = "hello world!"
sock.send(struct.pack(">h%ds"%len(msg), len(msg), msg))
print sock.recv(1024)  
sock.close()
